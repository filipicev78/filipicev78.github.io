let happiness = 0;
let belly = 0;
let strength = 0;
let status = 0;

function feedPet() {
    console.log("feeding  da penguin")
}

function bellySled() {
    console.log("belly sledding")
}

function fishingTrip() {
    console.log(" fishing trip")
}

function huddleForHeat() {
    console.log("huddle for warmth")
}